import express from "express";
import cors from "cors";
import servicesRoute from "./routes/services.js";
import subServicesRoute from "./routes/subServices.js";
import stylistsRoute from "./routes/stylists.js";
import availabilityRoute from "./routes/availability.js";
import bookingRoute from "./routes/booking.js";

const app = express();

app.use(cors());
app.use(express.json());

app.use("/services", servicesRoute);
app.use("/sub-services", subServicesRoute);
app.use("/stylists", stylistsRoute);
app.use("/availability", availabilityRoute);
app.use("/booking", bookingRoute);

app.get("/", (req, res) => {
  res.send("API is running...");
});

const PORT = process.env.PORT || 10000;

app.listen(PORT, () => {
  console.log("Server running on port " + PORT);
});