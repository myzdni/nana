import { createClient } from "@supabase/supabase-js";

const SUPABASE_URL = "https://tlvhpybxrlysirigjfup.supabase.co";
const SUPABASE_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsdmhweWJ4cmx5c2lyaWdqZnVwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM0ODY2MDcsImV4cCI6MjA3OTA2MjYwN30.QknwMSSCodorgKOzwRIl3j8eNV7RWcqOS-eeSUz9QXc";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON);