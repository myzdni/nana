router.delete("/:id", async (req, res) => {
    const { id } = req.params;

    try {
        const { error } = await supabase
            .from("bookings")
            .delete()
            .eq("id", id);

        if (error) throw error;

        return res.json({
            success: true,
            message: "رزرو با موفقیت لغو شد",
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "خطا در لغو رزرو",
        });
    }
});