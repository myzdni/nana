router.get("/list", async (req, res) => {
    try {
        const { data, error } = await supabase
            .from("bookings")
            .select("*")
            .order("created_at", { ascending: false });

        if (error) throw error;

        return res.json({
            success: true,
            data,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({
            success: false,
            message: "خطا در دریافت لیست رزروها",
        });
    }
});