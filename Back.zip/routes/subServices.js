import express from "express";
import { supabase } from "../supabaseClient.js";

const router = express.Router();

/**
 * GET /sub-services
 * اگر service_id کوئری بدی فقط زیرخدمت‌های اون سرویس رو میاره
 * مثلا: /sub-services?service_id=1
 */
router.get("/", async (req, res) => {
  const { service_id } = req.query;

  let query = supabase.from("sub_services").select("*").order("created_at", {
    ascending: false,
  });

  if (service_id) {
    query = query.eq("service_id", service_id);
  }

  const { data, error } = await query;

  if (error) {
    console.error("Error fetching sub_services:", error);
    return res
      .status(500)
      .json({ success: false, message: "Server error (sub_services)" });
  }

  return res.json({ success: true, data });
});

/**
 * POST /sub-services
 * بدنه‌ی درخواست (JSON):
 * {
 *   "service_id": 1,
 *   "name": "رنگ کامل",
 *   "duration_minutes": 90,
 *   "price": 800000
 * }
 */
router.post("/", async (req, res) => {
  const { service_id, name, duration_minutes, price } = req.body;

  if (!service_id || !name) {
    return res.status(400).json({
      success: false,
      message: "service_id و name الزامی هستند",
    });
  }

  const { data, error } = await supabase
    .from("sub_services")
    .insert([{ service_id, name, duration_minutes, price }])
    .select();

  if (error) {
    console.error("Error inserting sub_service:", error);
    return res
      .status(500)
      .json({ success: false, message: "Server error (insert)" });
  }

  return res.json({ success: true, data: data[0] });
});

export default router;