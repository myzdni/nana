import express from "express";
import { supabase } from "../supabaseClient.js";

const router = express.Router();

// GET همه خدمات
router.get("/", async (req, res) => {
  const { data, error } = await supabase
    .from("services")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    console.error(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }

  return res.json({ success: true, data });
});

// POST اضافه کردن خدمت جدید
router.post("/", async (req, res) => {
  const { name } = req.body;

  const { data, error } = await supabase
    .from("services")
    .insert([{ name }])
    .select();

  if (error) {
    console.error(error);
    return res.status(500).json({ success: false, message: "Server error" });
  }

  return res.json({ success: true, data: data[0] });
});

export default router;