import express from "express";
import { supabase } from "../supabaseClient.js";

const router = express.Router();

// ---------------------------------------------------------
// CREATE BOOKING
// ---------------------------------------------------------
router.post("/", async (req, res) => {
  const {
    customer_name,
    customer_phone,
    service_id,
    sub_service_id,
    stylist_id,
    date,
    time,
    discount_code
  } = req.body;

  // Step 0 — Required fields check
  if (!customer_name || !customer_phone || !service_id || !stylist_id || !date || !time) {
    return res.status(400).json({
      success: false,
      message: "تمام فیلدها اجباری هستند",
    });
  }

  // Step 1 — Check if time already booked (only active bookings)
  const { data: existingBooking, error: checkError } = await supabase
    .from("bookings")
    .select("*")
    .eq("stylist_id", stylist_id)
    .eq("date", date)
    .eq("time", time)
    .eq("status", "active");

  if (checkError) {
    return res.json({
      success: false,
      message: "خطا در بررسی تایم!",
    });
  }

  if (existingBooking && existingBooking.length > 0) {
    return res.status(400).json({
      success: false,
      message: "این تایم قبلاً رزرو شده است.",
    });
  }

  // Step 2 — Calculate price (Service + Sub-service)
  let finalPrice = 0;

  // Main service price
  const { data: mainService, error: mainError } = await supabase
    .from("services")
    .select("price")
    .eq("id", service_id)
    .single();

  if (mainError || !mainService) {
    return res.json({
      success: false,
      message: "خطا در دریافت قیمت سرویس!",
    });
  }

  finalPrice += mainService.price;

  // Sub service price
  if (sub_service_id) {
    const { data: subService, error: subError } = await supabase
      .from("sub_services")
      .select("price")
      .eq("id", sub_service_id)
      .single();

    if (subError || !subService) {
      return res.json({
        success: false,
        message: "خطا در دریافت قیمت زیرسرویس!",
      });
    }

    finalPrice += subService.price;
  }

  // Step 2.2 — Dynamic Discount
  let discountPercent = 0;
  let discountAmount = 0;

  if (discount_code) {
    const { data: discount, error: discountError } = await supabase
      .from("discount_codes")
      .select("*")
      .eq("code", discount_code)
      .eq("is_active", true)
      .single();

    if (!discountError && discount) {
      const now = new Date();
      const exp = discount.expiry_date ? new Date(discount.expiry_date) : null;

      const isValidDate = !exp || now <= exp;

      if (isValidDate) {
        if (discount.percent) discountPercent = discount.percent;
        if (discount.amount) discountAmount = discount.amount;
      }
    }
  }

  // Apply percent discount
  if (discountPercent > 0) {
    finalPrice -= (finalPrice * discountPercent) / 100;
  }

  // Apply fixed amount discount
  if (discountAmount > 0) {
    finalPrice -= discountAmount;
  }

  if (finalPrice < 0) finalPrice = 0;
  finalPrice = Math.round(finalPrice);

  // Step 3 — Insert booking
  const { data: bookingData, error: bookingError } = await supabase
    .from("bookings")
    .insert([
      {
        customer_name,
        customer_phone,
        service_id,
        sub_service_id,
        stylist_id,
        date,
        time,
        price: finalPrice,
        discount_code: discount_code || null,
        status: "active"
      }
    ])
    .select();

  if (bookingError) {
    return res.status(500).json({
      success: false,
      message: "خطا در ثبت رزرو",
    });
  }

  return res.json({
    success: true,
    message: "رزرو با موفقیت ثبت شد",
    booking: bookingData[0]
  });
});

// ---------------------------------------------------------
// CANCEL BOOKING
// ---------------------------------------------------------
router.delete("/:id", async (req, res) => {
  const { id } = req.params;

  const { data, error } = await supabase
    .from("bookings")
    .update({ status: "canceled" })
    .eq("id", id)
    .select();

  if (error) {
    console.error("Cancel Error:", error);
    return res.status(500).json({
      success: false,
      message: "خطا در لغو رزرو!",
    });
  }

  return res.json({
    success: true,
    message: "رزرو با موفقیت لغو شد!",
    data: data[0]
  });
});

// GET AVAILABLE SLOTS
router.get("/available", async (req, res) => {
  const { stylist_id, date } = req.query;

  if (!stylist_id || !date) {
    return res.status(400).json({
      success: false,
      message: "stylist_id و date الزامی هستند"
    });
  }

  // 1) دریافت ساعات شیفت از availability
  const { data: shifts, error: shiftError } = await supabase
    .from("availability")
    .select("time, is_available")
    .eq("stylist_id", stylist_id)
    .eq("date", date);

  if (shiftError) {
    return res.status(500).json({
      success: false,
      message: "خطا در دریافت شیفت‌ها"
    });
  }

  // اگر شیفتی نبود → یعنی تعطیل است
  if (!shifts || shifts.length === 0) {
    return res.json({
      success: true,
      slots: []
    });
  }

  // 2) دریافت رزروهای فعال آن روز
  const { data: booked, error: bookedError } = await supabase
    .from("bookings")
    .select("time")
    .eq("stylist_id", stylist_id)
    .eq("date", date)
    .eq("status", "active");

  if (bookedError) {
    return res.status(500).json({
      success: false,
      message: "خطا در بررسی رزروها"
    });
  }

  const bookedTimes = booked.map(item => item.time);

  // 3) ترکیب availability + bookings
  const slots = shifts.map(slot => {
    if (!slot.is_available) {
      return { time: slot.time, status: "disabled" }; // خاکستری
    }

    if (bookedTimes.includes(slot.time)) {
      return { time: slot.time, status: "booked" }; // قرمز
    }

    return { time: slot.time, status: "available" }; // طوسی
  });

  return res.json({
    success: true,
    slots
  });
});

export default router;