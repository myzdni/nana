import express from "express";
import { supabase } from "../supabaseClient.js";

const router = express.Router();

/**
 * GET /stylists
 * تمام آرایشگرها را می‌آورد
 */
router.get("/", async (req, res) => {
  const { data, error } = await supabase
    .from("stylists")
    .select("*")
    .order("created_at", { ascending: false });

  if (error) {
    console.error("Error fetching stylists:", error);
    return res.status(500).json({ success: false, message: "Server error (stylists)" });
  }

  return res.json({ success: true, data });
});

/**
 * POST /stylists
 * اضافه کردن آرایشگر جدید
 * {
 *   "full_name": "آیلین",
 *   "avatar_url": "https://example.com/aylin.jpg",
 *   "bio": "متخصص رنگ و کوتاهی"
 * }
 */
router.post("/", async (req, res) => {
  const { full_name, avatar_url, bio } = req.body;

  if (!full_name) {
    return res.status(400).json({
      success: false,
      message: "full_name الزامی است",
    });
  }

  const { data, error } = await supabase
    .from("stylists")
    .insert([{ full_name, avatar_url, bio }])
    .select();

  if (error) {
    console.error("Error inserting stylist:", error);
    return res.status(500).json({ success: false, message: "Server error (insert stylist)" });
  }

  return res.json({ success: true, data: data[0] });
});

export default router;