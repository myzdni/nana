import express from "express";
import { supabase } from "../supabaseClient.js";

const router = express.Router();

/**
 * GET /availability?stylist_id=uuid&date=2025-01-01
 * برمی‌گردونه ساعت‌های خالی و پر یک آرایشگر در یک روز
 */
router.get("/", async (req, res) => {
  const { stylist_id, date } = req.query;

  if (!stylist_id || !date) {
    return res.status(400).json({
      success: false,
      message: "stylist_id و date الزامی هستند",
    });
  }

  const { data, error } = await supabase
    .from("availability")
    .select("*")
    .eq("stylist_id", stylist_id)
    .eq("date", date)
    .order("time", { ascending: true });

  if (error) {
    console.error("Error fetching availability:", error);
    return res
      .status(500)
      .json({ success: false, message: "Server error (availability)" });
  }

  return res.json({ success: true, data });
});

/**
 * POST /availability
 * بدنهٔ درخواست:
 * {
 *   "stylist_id": "uuid",
 *   "date": "2025-01-01",
 *   "time": "14:30"
 * }
 * یعنی یک زمان آزاد جدید برای آرایشگر بساز
 */
router.post("/", async (req, res) => {
  const { stylist_id, date, time } = req.body;

  if (!stylist_id || !date || !time) {
    return res.status(400).json({
      success: false,
      message: "تمام فیلدها الزامی هستند",
    });
  }

  const { data, error } = await supabase
    .from("availability")
    .insert([{ stylist_id, date, time }])
    .select();

  if (error) {
    console.error("Error inserting availability:", error);
    return res
      .status(500)
      .json({ success: false, message: "Server error (insert availability)" });
  }

  return res.json({ success: true, data: data[0] });
});

/**
 * PATCH /availability/book
 * رزرو کردن یک زمان (is_booked = true)
 */
router.patch("/book", async (req, res) => {
  const { id } = req.body;

  if (!id) {
    return res.status(400).json({
      success: false,
      message: "id الزامی است",
    });
  }

  const { data, error } = await supabase
    .from("availability")
    .update({ is_booked: true })
    .eq("id", id)
    .select();

  if (error) {
    console.error("Error booking time:", error);
    return res
      .status(500)
      .json({ success: false, message: "Server error (book time)" });
  }

  return res.json({ success: true, data: data[0] });
});

export default router;